-- AlterTable
ALTER TABLE "public"."Batch" ADD COLUMN     "description" TEXT;
