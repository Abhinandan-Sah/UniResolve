'use client';

import React, { useEffect, useState } from 'react';
import {
  Plus,
  FileText,
  Users,
  Clock,
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  GraduationCap,
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { CreateTestDialog } from '@/components/CreateTestDialog';
import TestEvaluation from './TestEvaluation';

interface Test {
  id: string;
  name: string;
  description: string;
  active: boolean;
  maximumMarks: number;
  createdAt: string;
  batch: {
    id: string;
    name: string;
  };
  _count: {
    questions: number;
    answers: number;
  };
}

export default function TestDashboard() {
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [evaluatingTestId, setEvaluatingTestId] = useState<string | null>(null);

  useEffect(() => {
    fetchTests();
  }, []);

  const fetchTests = async () => {
    try {
      const response = await fetch('/api/tests');
      const data = await response.json();
      setTests(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to fetch tests:', error);
      setTests([]);
    } finally {
      setLoading(false);
    }
  };

  const handleTestCreated = (newTest: Test) => {
    setTests((prev) => [...prev, newTest]);
    setIsCreateDialogOpen(false);
  };

  const toggleTestStatus = async (testId: string, currentStatus: boolean) => {
    try {
      await fetch(`/api/tests/${testId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: !currentStatus }),
      });

      setTests((prev) =>
        prev.map((test) =>
          test.id === testId ? { ...test, active: !currentStatus } : test
        )
      );
    } catch (error) {
      console.error('Failed to update test status:', error);
    }
  };

  const totalQuestions = tests.reduce(
    (sum, test) => sum + (test._count?.questions || 0),
    0
  );
  const activeTests = tests.filter((test) => test.active).length;

  if (loading) {
    return (
      <div className='flex items-center justify-center h-64'>
        <div className='animate-spin rounded-full h-8 w-8 border-b-2 border-primary'></div>
      </div>
    );
  }

  // If evaluating a test, show the evaluation interface
  if (evaluatingTestId) {
    return (
      <TestEvaluation
        testId={evaluatingTestId}
        onBack={() => setEvaluatingTestId(null)}
      />
    );
  }

  return (
    <div className='space-y-6'>
      {/* Header */}
      <div className='flex items-center justify-between'>
        <div>
          <h1 className='text-3xl font-bold tracking-tight'>Tests</h1>
          <p className='text-muted-foreground'>
            Create and manage tests for your batches
          </p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)}>
          <Plus className='mr-2 h-4 w-4' />
          Create Test
        </Button>
      </div>

      {/* Stats Cards */}
      <div className='grid gap-4 md:grid-cols-4'>
        <Card>
          <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
            <CardTitle className='text-sm font-medium'>Total Tests</CardTitle>
            <FileText className='h-4 w-4 text-muted-foreground' />
          </CardHeader>
          <CardContent>
            <div className='text-2xl font-bold'>{tests.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
            <CardTitle className='text-sm font-medium'>Active Tests</CardTitle>
            <Clock className='h-4 w-4 text-muted-foreground' />
          </CardHeader>
          <CardContent>
            <div className='text-2xl font-bold'>{activeTests}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
            <CardTitle className='text-sm font-medium'>
              Total Questions
            </CardTitle>
            <FileText className='h-4 w-4 text-muted-foreground' />
          </CardHeader>
          <CardContent>
            <div className='text-2xl font-bold'>{totalQuestions}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
            <CardTitle className='text-sm font-medium'>Total Marks</CardTitle>
            <Users className='h-4 w-4 text-muted-foreground' />
          </CardHeader>
          <CardContent>
            <div className='text-2xl font-bold'>
              {tests.reduce((sum, test) => sum + test.maximumMarks, 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tests Table */}
      <Card>
        <CardHeader>
          <CardTitle>Your Tests</CardTitle>
          <CardDescription>
            A list of all your tests and their details
          </CardDescription>
        </CardHeader>
        <CardContent>
          {tests.length === 0 ? (
            <div className='text-center py-8'>
              <p className='text-muted-foreground'>
                No tests found. Create your first test to get started.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Test Name</TableHead>
                  <TableHead>Batch</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Questions</TableHead>
                  <TableHead>Submissions</TableHead>
                  <TableHead>Max Marks</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className='text-right'>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tests.map((test) => (
                  <TableRow key={test.id}>
                    <TableCell>
                      <div>
                        <div className='font-medium'>{test.name}</div>
                        <div className='text-sm text-muted-foreground truncate max-w-[200px]'>
                          {test.description}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant='outline'>{test.batch.name}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={test.active ? 'default' : 'secondary'}
                        className='cursor-pointer'
                        onClick={() => toggleTestStatus(test.id, test.active)}
                      >
                        {test.active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant='secondary'>
                        {test._count?.questions || 0} questions
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant='outline'>
                        {test._count?.answers || 0} submissions
                      </Badge>
                    </TableCell>
                    <TableCell className='font-medium'>
                      {test.maximumMarks} marks
                    </TableCell>
                    <TableCell className='text-sm text-muted-foreground'>
                      {new Date(test.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className='text-right'>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant='ghost' className='h-8 w-8 p-0'>
                            <MoreHorizontal className='h-4 w-4' />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align='end'>
                          <DropdownMenuItem
                            onClick={() => setEvaluatingTestId(test.id)}
                          >
                            <GraduationCap className='mr-2 h-4 w-4' />
                            Evaluate & Grade
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <CreateTestDialog
        open={isCreateDialogOpen}
        onOpenChange={setIsCreateDialogOpen}
        onTestCreated={handleTestCreated}
      />
    </div>
  );
}
