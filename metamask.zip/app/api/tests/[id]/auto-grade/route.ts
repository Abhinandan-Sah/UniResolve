import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenerativeAI } from "@google/generative-ai";
import { PrismaClient } from '@/lib/generated/prisma';

const prisma = new PrismaClient();
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_GEMINI_API_KEY!);

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    console.log('Starting auto-grading for test:', id);

    // Get ALL answers for this test
    const answers = await prisma.answer.findMany({
      where: {
        testId: id,
      },
      include: {
        question: true,
      },
    });

    console.log(`Found ${answers.length} answers to grade`);

    if (answers.length === 0) {
      return NextResponse.json(
        { message: 'No answers to grade', gradedCount: 0 },
        { status: 200 }
      );
    }

    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    let gradedCount = 0;
    const errors: string[] = [];

    for (const answer of answers) {
      try {
        console.log(
          `Grading answer ${answer.id} for question: ${answer.question.orderForAi}`
        );

        const prompt = `You are an expert teacher grading a student's answer.

Question (${answer.question.marks} marks):
${answer.question.text}

Student's Answer:
${answer.answer}

Instructions:
1. Grade this answer out of ${answer.question.marks} marks
2. Provide brief constructive remarks (2-3 sentences)
3. Be fair and objective

IMPORTANT: Respond with ONLY valid JSON in this exact format:
{
  "marks": <number between 0 and ${answer.question.marks}>,
  "remarks": "<your brief feedback here>"
}`;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const content = response.text();

        console.log('Gemini grading response:', content);

        // Clean JSON response
        let cleanContent = content.trim();
        if (cleanContent.startsWith('```json')) {
          cleanContent = cleanContent
            .replace(/^```json\s*/, '')
            .replace(/\s*```$/, '');
        } else if (cleanContent.startsWith('```')) {
          cleanContent = cleanContent
            .replace(/^```\s*/, '')
            .replace(/\s*```$/, '');
        }

        const jsonMatch = cleanContent.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          cleanContent = jsonMatch[0];
        }

        const grading = JSON.parse(cleanContent);

        // Validate the response
        if (
          typeof grading.marks !== 'number' ||
          grading.marks < 0 ||
          grading.marks > answer.question.marks
        ) {
          throw new Error('Invalid marks in response');
        }

        // Update the answer with grading
        await prisma.answer.update({
          where: { id: answer.id },
          data: {
            marksScored: grading.marks,
            remarks: grading.remarks || '',
          },
        });

        gradedCount++;
        console.log(
          `Successfully graded answer ${answer.id}: ${grading.marks}/${answer.question.marks}`
        );
      } catch (error: any) {
        console.error(`Failed to grade answer ${answer.id}:`, error);
        errors.push(`Answer ${answer.id}: ${error.message}`);
      }
    }

    console.log(`Auto-grading completed: ${gradedCount}/${answers.length} answers graded`);

    return NextResponse.json({
      message: `Graded ${gradedCount} out of ${answers.length} answers`,
      gradedCount,
      totalAnswers: answers.length,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error: any) {
    console.error('Error in auto-grading:', error);

    if (error.message?.includes('quota')) {
      return NextResponse.json(
        { error: 'Google Gemini API quota exceeded.' },
        { status: 402 }
      );
    }

    if (error.message?.includes('API key')) {
      return NextResponse.json(
        { error: 'Invalid Google Gemini API key' },
        { status: 401 }
      );
    }

    return NextResponse.json(
      { error: error.message || 'Failed to auto-grade answers' },
      { status: 500 }
    );
  }
}