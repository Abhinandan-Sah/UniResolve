import BatchDashboard from '@/components/BatchDashboard';

export default function Page() {
  return <BatchDashboard />;
}
