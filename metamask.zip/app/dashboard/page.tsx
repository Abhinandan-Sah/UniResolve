import MainDashboard from "@/components/MainDashboard";

export default function Dashboard() {
    return (
        <div>
            <MainDashboard />
        </div>
    );
}