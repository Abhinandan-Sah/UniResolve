import TestDashboard from '@/components/TestDashboard';

export default function Page() {
  return (
    <div>
      <TestDashboard />
    </div>
  );
}
